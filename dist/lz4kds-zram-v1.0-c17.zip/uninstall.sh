#!/system/bin/sh
rm -rf /metadata/vold/ksu/preinit/lz4kds
