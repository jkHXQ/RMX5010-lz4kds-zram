#!/system/bin/sh
ui_print "- LZ4KDS 内存压缩（安卓17 / 6.6.118 专用包）"
ui_print "- 算法来源: Crystal HybridSwap (SDDC) / HiSilicon (LZ4KD)"
ui_print "- 驱动骨架: OPPO/realme oplus_bsp_hybridswap_zram"
ui_print "- 已按 6.6.118-android15-8 原厂 ko 对齐 CRC"
ui_print "- 修改: sh /data/adb/modules/lz4kds/zram.sh 16384 lz4kds"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/zram.sh 0 0 0755
set_perm $MODPATH/webroot/webui.sh 0 0 0755
set_perm $MODPATH/webroot/index.html 0 0 0644
set_perm $MODPATH/uninstall.sh 0 0 0755
