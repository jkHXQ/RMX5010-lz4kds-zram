LZ4KDS zram 适配层 v1.0-c17（安卓17 专用）

【适用】
仅用于内核 6.6.118-android15-8（112_C17 及以上）。
6.6.89 请使用 lz4kds-zram-v1.0.zip，不要混用。

【与通用包的区别】
- zram KO 已按 6.6.118 原厂 ko 重新对齐 4 个导出符号 CRC
- zsmalloc 使用新系统原厂（多出 zs_lookup_class_index_oplus）
- 其余（脚本、WebUI、自检流程）与通用包一致

【算法与代码来源】
- 驱动骨架 / hybridswap / writeback / memcg: OPPO·realme 原厂
- LZ4KD 编解码: HiSilicon（华为）
- SDDC 索引/引用/alias/delta 设计: Crystal HybridSwap (Wcoom)
- 本包只做适配与集成，不含算法原创

【安装】
KernelSU Manager 安装 zip 后重启。

【验证】
cat /sys/block/zram0/comp_algorithm
cat /sys/block/zram0/sddc_stat
cat /sys/module/oplus_bsp_hybridswap_zram/parameters/selftest_codec

【回退】
卸载模块或放入 disable 文件后重启，系统自动使用原厂 zram。

【风险】
修改内核内存管理路径，可能卡顿或无法开机；仅供学习研究，风险自负。
