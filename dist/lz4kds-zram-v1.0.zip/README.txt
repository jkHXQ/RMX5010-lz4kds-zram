LZ4KDS zram 适配层 v1.0

【这是什么】
在 OPPO/realme 原厂 oplus_bsp_hybridswap_zram 驱动上，以可回退方式接入
LZ4KD 压缩 + SDDC 相似页/增量压缩。通过 KernelSU preinit 早期加载。

【算法与代码来源】
- 驱动骨架 / hybridswap / writeback / memcg: OPPO·realme 原厂
- LZ4KD 编解码: HiSilicon（华为）
- SDDC 索引/引用/alias/delta 设计: Crystal HybridSwap (Wcoom)
- 本包只做适配与集成，不含算法原创

【安装】
KernelSU Manager 安装 zip，或解压到 /data/adb/modules/lz4kds 后重启。

【配置】
方式一（推荐）：KernelSU Manager → 模块 → lz4kds → 打开，用界面改容量和算法。
方式二：文件 /data/adb/modules/lz4kds/preinit/preinit.conf
  zram_size_mb=9216    zram0 容量 MiB（512-65536，0=厂商值）
  zram_algo=lz4kds     压缩算法（lz4kds/lz4kd/lz4/zstd/lzo/lzo-rle/off）
修改后: ksud initrc refresh && reboot
或用工具: sh /data/adb/modules/lz4kds/zram.sh 9216 lz4kds

【验证】
cat /sys/block/zram0/disksize
cat /sys/block/zram0/comp_algorithm
cat /sys/block/zram0/sddc_stat
cat /sys/module/oplus_bsp_hybridswap_zram/parameters/selftest_codec
cat /sys/module/oplus_bsp_hybridswap_zram/parameters/selftest_io
日志: /data/adb/modules/lz4kds/selftest.log

【回退】
KernelSU Manager 中禁用/卸载本模块，或重启前放入 disable 文件；
卸载后系统自动使用原厂 zram。

【风险】
修改内核内存管理路径，可能卡顿或无法开机；仅供学习研究，风险自负。
